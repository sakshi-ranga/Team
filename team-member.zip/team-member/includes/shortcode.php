<?php

function your_shortcode_wp_enqueue_scripts_fun() {

    wp_register_script( 'team-js', plugins_url('/team-member/assets/js/custom.js'), array( 'jquery' ), '1.0', true );
    wp_localize_script('team-js', 'customAjax', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
    ));
    wp_register_style('team-styles', plugins_url('/team-member/assets/css/style.css'));
   
}
add_action( 'wp_enqueue_scripts', 'your_shortcode_wp_enqueue_scripts_fun');

function team_display_shortcode(){

    ob_start();

    $department_terms = get_terms(array(
        'taxonomy' => 'department',
        'hide_empty' => false, 
    ));
    echo '<div class"teams-page">';
    if (!empty($department_terms) && !is_wp_error($department_terms)) {
        echo '<select id="taxonomySelect"><option value="">Select Taxonomy</option>';
        foreach ($department_terms as $taxonomy) {
            echo '<option value="' . esc_attr($taxonomy->slug) . '">' . esc_html($taxonomy->name) . '</option>';
        } 
        echo '</select>';
    }
    echo '<div class="teams" id="teams"></div></div>';
    wp_enqueue_style('team-styles');
    wp_enqueue_script('team-js');
    return ob_get_clean();
}

add_shortcode('display_team', 'team_display_shortcode');

function display_team_members() {

   
    $args = array(
        'post_type' => 'team'
    );
    if(isset($_POST['department']) && $_POST['department'] !== ''){
        $termslug = array(
            array (
                'taxonomy' => 'department',
                'field' => 'slug',
                'terms' => trim($_POST['department']),
            )
        );
        $args['tax_query'] = $termslug;

    }

    $the_query = new WP_Query($args);
    $html = '<ul>'; 
    if ($the_query->have_posts()) {
        while ($the_query->have_posts()) {
            $the_query->the_post();
            $post_thumbnail = get_the_post_thumbnail(get_the_ID(), 'thumbnail'); 
            if (empty($post_thumbnail)) {
                $post_thumbnail = '<img src="' . plugins_url('/team-member/assets/images/avtaar.jpg') . '" alt="Default Image">';
            }
            $html .= '<li><div class="team-member">
                    '.$post_thumbnail.'
                    <div class="name">' . get_the_title() . '</div>
                    <div class="email"> Email :'. get_field('email') . '</div>
                    <div class="bio">Bio :'. get_field('bio'). 
                '</div></div></li>';
        }
    } else {
        $html .= '<li><div class="team-member">No team members found</div></li>';
    }

    $html .= '</ul>'; 
    wp_reset_postdata();
    wp_send_json_success($html);
}

add_action('wp_ajax_display_team_members', 'display_team_members');
add_action('wp_ajax_nopriv_display_team_members', 'display_team_members');



